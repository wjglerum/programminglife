/**
 * Provides the connection between the model and view.
 */
package controllers;
