/**
 * This package contains everything for the patient,
 * so we can save them into a database and more.
 */
package models.patient;
