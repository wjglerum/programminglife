/**
 * Provides the code for the chromosome view.
 */
package models.chromosome;