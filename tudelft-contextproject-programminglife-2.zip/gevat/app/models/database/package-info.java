/**
 * This package provides all database interaction.
 */
package models.database;
