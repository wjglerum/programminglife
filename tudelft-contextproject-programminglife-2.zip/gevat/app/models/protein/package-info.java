/**
 * Provides classes for proteins and connections between proteins.
 */
package models.protein;
