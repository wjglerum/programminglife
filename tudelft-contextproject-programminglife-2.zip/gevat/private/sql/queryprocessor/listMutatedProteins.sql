SELECT DISTINCT protein_a_id
FROM protein_connections
WHERE p_id = ?;
