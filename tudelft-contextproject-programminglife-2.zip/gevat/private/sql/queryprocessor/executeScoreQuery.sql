SELECT 
	*
FROM
	score 
WHERE 
	chrom = ? AND 
	position = ?;
