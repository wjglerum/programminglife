SELECT DISTINCT 
	locus_symbol 
FROM
	b138_SNPContigLocusId 
WHERE 
	snp_id = ?;
