INSERT INTO mutations 
VALUES
	(nextval('m_id_seq'::regclass),
	?,
	?,
	?,
	?,
	?,
	?,
	?,
	?,
	?,
	?);
