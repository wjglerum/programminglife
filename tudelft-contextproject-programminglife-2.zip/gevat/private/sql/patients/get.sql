SELECT 
	* 
FROM 
	patient 
WHERE 
	p_id = ? AND 
	u_id= ?;
