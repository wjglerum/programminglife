SELECT 
	* 
FROM 
	patient 
WHERE 
	u_id = ?;
