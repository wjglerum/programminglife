DELETE 
FROM 
	patient 
WHERE 
	p_id = ?;
