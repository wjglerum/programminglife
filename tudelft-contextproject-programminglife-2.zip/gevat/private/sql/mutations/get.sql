SELECT 
	* 
FROM 
	mutations 
WHERE 
	p_id = ? and 
	chromosome = ?;
